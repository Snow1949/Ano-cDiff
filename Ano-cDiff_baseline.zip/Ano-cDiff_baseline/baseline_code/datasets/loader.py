import numpy as np
import random
import torch

from baseline_code.datasets.load_brats import BrainDataset


def seed_worker(worker_id):
    np.random.seed(worker_id)
    random.seed(0)

g = torch.Generator()
g.manual_seed(0)


def get_data_loader(dataset, config, split_set, generator = True):
    if dataset == "brats":    # data.path："chenxue/dataset/brain/MICCAI_BraTS2020"， sampling.batch_size = 64， 'train'
        loader = get_data_loader_brats(config.data.path, config.sampling.batch_size, split_set=split_set,
                                            sequence_translation = config.data.sequence_translation)
    else:
        raise Exception("Dataset does exit")
    
    return get_generator_from_loader(loader) if generator else loader


def get_data_loader_brats(path, batch_size, split_set: str = 'train',
                             sequence_translation : bool = False, 
                             healthy_data_percentage : float = 0.35):

    # data.path："chenxue/dataset/brain/MICCAI_BraTS2020"， batch_size=64， 'train'
    assert split_set in ["train", "val", "test"]
    default_kwargs = {"drop_last": True, "batch_size": batch_size, "pin_memory" : True, "num_workers": 8,
                    "prefetch_factor" : 8, "worker_init_fn" : seed_worker, "generator": g,}

    if split_set == "test":
        default_kwargs["shuffle"] = False
        default_kwargs["num_workers"] = 1
        dataset = BrainDataset(path, n_tumour_patients = None,
                               n_healthy_patients = 0, split = split_set, 
                               sequence_translation = sequence_translation,
                               )
        print(f"test dataset lenght: {len(dataset)}")   # 34847
        # print("**********print dataset***************")
        # print(dataset.dataset )
        # print("**********print dataset***************")
        return torch.utils.data.DataLoader(dataset, **default_kwargs)
    else:
        default_kwargs["shuffle"] = True
        default_kwargs["num_workers"] = 4
        dataset_healthy = BrainDataset(path, split = split_set,             # path："chenxue/dataset/brain/MICCAI_BraTS2020"
                n_tumour_patients=0, n_healthy_patients=None,
                skip_healthy_s_in_tumour=True,skip_tumour_s_in_healthy=True,
                )
        print("len(dataset_healthy):{}".format(int(len(dataset_healthy))))  # len(dataset_healthy):70335
        print('~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~')
        print('~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~')
        dataset_unhealthy = BrainDataset(path, split = split_set,
                n_tumour_patients=None, n_healthy_patients=0,
                skip_healthy_s_in_tumour=True,skip_tumour_s_in_healthy=True,
                )
        print("len(dataset_unhealthy):{}".format(int(len(dataset_unhealthy))))  # len(dataset_unhealthy):60281张切片

        print('~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~')
        print('~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~')
        if healthy_data_percentage is not None:
            print("healthy_data_percentage is not None:")
            healthy_size = int(len(dataset_healthy)*healthy_data_percentage)    # 70335张切片
            unhealthy_size = len(dataset_unhealthy)                             # 60281张切片
            total_size = healthy_size + unhealthy_size                          # 130616
            samples_weight = torch.cat([torch.ones(healthy_size) * total_size / healthy_size,
                                        torch.ones(unhealthy_size) * total_size / unhealthy_size]
                                        ).double()
            sampler = torch.utils.data.WeightedRandomSampler(samples_weight, len(samples_weight))
            default_kwargs["sampler"] = sampler
            default_kwargs.pop('shuffle', None) # shuffle and sampler are mutually exclusive 通常互斥

            dataset = torch.utils.data.dataset.ConcatDataset([torch.utils.data.Subset(dataset_healthy, range(0, int(len(dataset_healthy)*healthy_data_percentage))),
                                 dataset_unhealthy])
        else:
            dataset = dataset_healthy
        
    print(f"dataset lenght: {len(dataset)}")        # 130616
    return torch.utils.data.DataLoader(dataset, **default_kwargs)


def get_generator_from_loader(loader):
    while True:
        yield from loader